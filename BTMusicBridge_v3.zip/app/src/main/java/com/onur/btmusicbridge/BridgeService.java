package com.onur.btmusicbridge;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.media.MediaBrowserServiceCompat;

import android.support.v4.media.MediaBrowserCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;

import java.util.Collections;
import java.util.List;

public class BridgeService extends MediaBrowserServiceCompat {
    private static final String ACTION = "com.bt.ACTION_AVRCP_MUSIC_ID3";
    private MediaSessionCompat session;

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!ACTION.equals(intent.getAction()) || session == null) return;

            String title = first(intent,
                    "EXTRA_AVRCP_ID3_TITLE",
                    "android.media.metadata.TITLE");

            String artist = first(intent,
                    "EXTRA_AVRCP_ID3_ARTIST",
                    "android.media.metadata.ARTIST");

            String album = first(intent,
                    "EXTRA_MEDIA_ABLUM",
                    "EXTRA_MEDIA_ALBUM",
                    "android.media.metadata.ALBUM");

            MediaMetadataCompat.Builder metadata = new MediaMetadataCompat.Builder();

            if (title != null)
                metadata.putString(MediaMetadataCompat.METADATA_KEY_TITLE, title);
            if (artist != null)
                metadata.putString(MediaMetadataCompat.METADATA_KEY_ARTIST, artist);
            if (album != null)
                metadata.putString(MediaMetadataCompat.METADATA_KEY_ALBUM, album);

            Bundle extras = intent.getExtras();
            if (extras != null) {
                for (String key : extras.keySet()) {
                    Object value = extras.get(key);
                    if (value instanceof Bitmap) {
                        Bitmap art = (Bitmap) value;
                        metadata.putBitmap(
                                MediaMetadataCompat.METADATA_KEY_ALBUM_ART, art);
                        metadata.putBitmap(
                                MediaMetadataCompat.METADATA_KEY_ART, art);
                        break;
                    }
                }
            }

            session.setMetadata(metadata.build());
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();

        session = new MediaSessionCompat(this, "BTMusicBridge");
        session.setFlags(
                MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS |
                MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS);

        session.setCallback(new MediaSessionCompat.Callback() {
            @Override public void onPlay() {
                session.setActive(true);
            }

            @Override public void onPause() {}

            @Override public void onSkipToNext() {}

            @Override public void onSkipToPrevious() {}
        });

        setSessionToken(session.getSessionToken());

        registerReceiver(receiver, new IntentFilter(ACTION));
        session.setActive(true);
    }

    private static String first(Intent intent, String... keys) {
        for (String key : keys) {
            String value = intent.getStringExtra(key);
            if (value != null && !value.isEmpty()) return value;
        }

        Bundle extras = intent.getExtras();
        if (extras != null) {
            for (String key : keys) {
                Object value = extras.get(key);
                if (value != null &&
                    !(value instanceof Bundle) &&
                    !(value instanceof Bitmap)) {
                    return String.valueOf(value);
                }
            }
        }
        return null;
    }

    @Override
    public BrowserRoot onGetRoot(
            String clientPackageName,
            int clientUid,
            @Nullable Bundle rootHints) {
        return new BrowserRoot("root", null);
    }

    @Override
    public void onLoadChildren(
            String parentId,
            Result<List<MediaBrowserCompat.MediaItem>> result) {
        result.sendResult(Collections.emptyList());
    }

    @Override
    public void onDestroy() {
        try {
            unregisterReceiver(receiver);
        } catch (Exception ignored) {
        }

        if (session != null) {
            session.release();
            session = null;
        }

        super.onDestroy();
    }
}
