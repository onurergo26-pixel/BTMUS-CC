BT Music Bridge v3

1) GitHub repo'ya bu ZIP'i yükleyin.
2) Actions workflow'unuzdaki "Find and extract project ZIP" adımı, ZIP'in adını otomatik bulur.
3) Build APK workflow'unu çalıştırın.
4) Başarılı olursa Artifacts > BTMusicBridge-APK.

Önemli: ZIP'in içindeki BUILD_WORKFLOW.yml otomatik olarak GitHub workflow'u olmaz; GitHub'da
.github/workflows/main.yml dosyasına workflow metnini koymanız gerekir.
